<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Blade</title>
</head>
<body>
    <h1>TEST {{$angka}} </h1>
    <!-- <h1>TEST <?php echo $angka ?> </h1> --> 
</body>
</html>